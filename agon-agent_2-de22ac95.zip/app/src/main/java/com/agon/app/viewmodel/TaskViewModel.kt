package com.agon.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.agon.app.data.TaskEntity
import com.agon.app.data.TaskRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TaskUiState(
    val input: String = "",
    val inputError: String? = null,
    val tasks: List<TaskEntity> = emptyList(),
    val isLoading: Boolean = true,
    val userMessage: String? = null,
) {
    val activeTasks: List<TaskEntity> = tasks.filterNot { it.isCompleted }
    val completedTasks: List<TaskEntity> = tasks.filter { it.isCompleted }
    val totalCount: Int = tasks.size
    val completedCount: Int = completedTasks.size
}

class TaskViewModel(private val repository: TaskRepository) : ViewModel() {
    private val inputState = MutableStateFlow("")
    private val inputErrorState = MutableStateFlow<String?>(null)
    private val messageState = MutableStateFlow<String?>(null)

    val uiState: StateFlow<TaskUiState> = combine(
        repository.tasks,
        inputState,
        inputErrorState,
        messageState,
    ) { tasks, input, error, message ->
        TaskUiState(
            input = input,
            inputError = error,
            tasks = tasks,
            isLoading = false,
            userMessage = message,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = TaskUiState(),
    )

    fun onInputChanged(value: String) {
        inputState.value = value
        if (value.trim().isNotEmpty()) inputErrorState.value = null
    }

    fun addTask() {
        val title = inputState.value.trim()
        if (title.isEmpty()) {
            inputErrorState.value = "اكتب عنوان المهمة أولاً"
            return
        }
        viewModelScope.launch {
            repository.addTask(title)
            inputState.value = ""
            inputErrorState.value = null
            messageState.value = "تمت إضافة المهمة"
        }
    }

    fun setCompleted(task: TaskEntity, completed: Boolean) {
        viewModelScope.launch {
            repository.setTaskCompleted(task, completed)
            messageState.value = if (completed) "تم نقل المهمة إلى المكتملة" else "تمت إعادة المهمة إلى النشطة"
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.deleteTask(task)
            messageState.value = "تم حذف المهمة"
        }
    }

    fun clearCompleted() {
        viewModelScope.launch {
            repository.clearCompleted()
            messageState.value = "تم تنظيف المهام المكتملة"
        }
    }

    fun messageShown() {
        messageState.update { null }
    }

    class Factory(private val repository: TaskRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(TaskViewModel::class.java)) {
                return TaskViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
