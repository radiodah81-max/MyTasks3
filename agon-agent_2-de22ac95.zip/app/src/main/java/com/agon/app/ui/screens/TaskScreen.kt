package com.agon.app.ui.screens

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.agon.app.data.TaskEntity
import com.agon.app.ui.components.EmptyTasksCard
import com.agon.app.ui.components.TaskInputCard
import com.agon.app.ui.components.TaskRow
import com.agon.app.ui.components.TaskSummaryCard
import com.agon.app.viewmodel.TaskUiState
import com.agon.app.viewmodel.TaskViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskScreen(
    viewModel: TaskViewModel,
    modifier: Modifier = Modifier,
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    var selectedTab by remember { mutableIntStateOf(0) }
    var showClearDialog by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.userMessage) {
        val message = uiState.userMessage
        if (message != null) {
            snackbarHostState.showSnackbar(message)
            viewModel.messageShown()
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("حذف المهام المكتملة؟") },
            text = { Text("سيتم حذف جميع المهام المكتملة نهائيًا من الجهاز.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showClearDialog = false
                        viewModel.clearCompleted()
                    },
                ) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { showClearDialog = false }) { Text("إلغاء") } },
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("مدير المهام", fontWeight = FontWeight.Bold)
                        Text("تنظيم هادئ ليوم أكثر وضوحًا", style = MaterialTheme.typography.bodySmall)
                    }
                },
                actions = {
                    IconButton(
                        enabled = uiState.completedTasks.isNotEmpty(),
                        onClick = { showClearDialog = true },
                    ) {
                        Icon(Icons.Outlined.DeleteSweep, contentDescription = "تنظيف المكتملة")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                ),
            )
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            PrimaryTabRow(selectedTabIndex = selectedTab, modifier = Modifier.fillMaxWidth()) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("المهام النشطة (${uiState.activeTasks.size})") },
                    icon = { Icon(Icons.Outlined.RadioButtonUnchecked, contentDescription = null) },
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("المهام المكتملة (${uiState.completedTasks.size})") },
                    icon = { Icon(Icons.Outlined.CheckCircle, contentDescription = null) },
                )
            }

            Crossfade(targetState = selectedTab, label = "task_tabs") { tab ->
                TaskListContent(
                    uiState = uiState,
                    showCompleted = tab == 1,
                    onInputChanged = viewModel::onInputChanged,
                    onAdd = viewModel::addTask,
                    onCheckedChange = viewModel::setCompleted,
                    onDelete = viewModel::deleteTask,
                )
            }
        }
    }
}

@Composable
private fun TaskListContent(
    uiState: TaskUiState,
    showCompleted: Boolean,
    onInputChanged: (String) -> Unit,
    onAdd: () -> Unit,
    onCheckedChange: (TaskEntity, Boolean) -> Unit,
    onDelete: (TaskEntity) -> Unit,
) {
    val visibleTasks = if (showCompleted) uiState.completedTasks else uiState.activeTasks

    if (uiState.isLoading) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) { CircularProgressIndicator() }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            TaskSummaryCard(activeCount = uiState.activeTasks.size, completedCount = uiState.completedTasks.size)
        }
        if (!showCompleted) {
            item {
                TaskInputCard(
                    value = uiState.input,
                    error = uiState.inputError,
                    onValueChange = onInputChanged,
                    onAdd = onAdd,
                )
            }
        }
        if (visibleTasks.isEmpty()) {
            item {
                Spacer(Modifier.height(8.dp))
                EmptyTasksCard(
                    title = if (showCompleted) "لا توجد مهام مكتملة بعد" else "قائمة نشطة فارغة",
                    description = if (showCompleted) "عند إنجاز مهمة ستظهر هنا مع وقت الإكمال." else "أضف مهمة من الحقل أعلاه وابدأ يومك بخطوة واضحة.",
                )
            }
        } else {
            items(visibleTasks, key = { it.id }) { task ->
                TaskRow(
                    task = task,
                    onCheckedChange = { checked -> onCheckedChange(task, checked) },
                    onDelete = { onDelete(task) },
                )
            }
        }
    }
}
