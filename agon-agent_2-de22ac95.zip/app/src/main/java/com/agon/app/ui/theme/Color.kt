package com.agon.app.ui.theme

import androidx.compose.ui.graphics.Color

val TealPrimary = Color(0xFF006A60)
val TealOnPrimary = Color(0xFFFFFFFF)
val TealPrimaryContainer = Color(0xFF9EF2E4)
val TealOnPrimaryContainer = Color(0xFF00201C)
val AmberSecondary = Color(0xFF6B5D00)
val AmberSecondaryContainer = Color(0xFFF8E46B)
val CoralTertiary = Color(0xFF8F4B38)
val CalmBackground = Color(0xFFFAFDF9)
val CalmSurface = Color(0xFFFAFDF9)

val DarkTealPrimary = Color(0xFF82D5C8)
val DarkTealOnPrimary = Color(0xFF003731)
val DarkTealContainer = Color(0xFF005047)
val DarkTealOnContainer = Color(0xFF9EF2E4)
val DarkAmberSecondary = Color(0xFFDBC84F)
val DarkCoralTertiary = Color(0xFFFFB5A0)
val DarkBackground = Color(0xFF111412)
val DarkSurface = Color(0xFF111412)
