package com.agon.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.agon.app.data.AppDatabase
import com.agon.app.data.TaskRepository
import com.agon.app.ui.screens.TaskScreen
import com.agon.app.ui.theme.AgonAppTheme
import com.agon.app.viewmodel.TaskViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: TaskViewModel by viewModels {
        val database = AppDatabase.getInstance(applicationContext)
        TaskViewModel.Factory(TaskRepository(database.taskDao()))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            AgonAppTheme {
                TaskScreen(viewModel = viewModel)
            }
        }
    }
}
